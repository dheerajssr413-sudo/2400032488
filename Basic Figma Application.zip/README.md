
  # Basic Figma Application

  This is a code bundle for Basic Figma Application. The original project is available at https://www.figma.com/design/RquDJjHs9ldprV47HVHaJg/Basic-Figma-Application.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  